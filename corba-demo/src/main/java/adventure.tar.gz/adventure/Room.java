package adventure;


/**
* adventure/Room.java .
* 由IDL-to-Java 编译器 (可移植), 版本 "3.2"生成
* 从adventure.idl
* 2016年1月31日 星期日 下午03时34分09秒 CST
*/


// relevant information about a room.
public interface Room extends RoomOperations, adventure.IPing, org.omg.CORBA.portable.IDLEntity 
{
} // interface Room
